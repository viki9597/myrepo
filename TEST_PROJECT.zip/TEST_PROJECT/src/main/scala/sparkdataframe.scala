import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext


case class Auction(auctionid: String, bid: Float, bidtime: Float, bidder: String, bidderrate: Integer, openbid: Float, price: Float, item: String, daystolive: Integer)

object sparkdataframe {
  def main(args: Array[String]): Unit = {
     println("Spark DataFrame")
     System.setProperty("hadoop.home.dir", "C:/winutil/");
    val sparkconf = new SparkConf().setAppName("Hello Spark").setMaster("local[*]");
    val sc = new SparkContext(sparkconf)
    val sqlContext = new SQLContext(sc)
    println("Query1")
    import sqlContext.implicits._
    import sqlContext._
    println("Query2")
    //Get the file and load it into spark context
    val ebayText = sc.textFile("C:/Users/vigneshshanmug1/workspace/sparkdataframeexample-master/ebay.csv")
    println("Query3")
    val ebay = ebayText.map(_.split(",")).map(p => Auction(p(0), p(1).toFloat, p(2).toFloat, p(3), p(4).toInt, p(5).toFloat, p(6).toFloat, p(7), p(8).toInt))
    val auction = ebay.toDF()
    println("Printing first 20 values")
    auction.show()
  }
}