import org.apache.spark.sql.catalyst.plans.logical.Intersect


object comparision {
  def main(args: Array[String]): Unit = {
    println("Dataframe Comparision");
    val DF1=(1,2,3,4,5)
    val DF2=(3,6,7,8,9,10)
    
    
  }
}