import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext

case class Employee(Name : String, Employee_ID : String, Designation : String)


object dataframe {
  def main(args: Array[String]): Unit = {
    println("Dataframe Example")
    val sparkconf = new SparkConf().setAppName("Hello Spark")
    val sc = new SparkContext(sparkconf)
    val sqlContext = new SQLContext(sc)
    println("Reading the file ... ... ")
    import sqlContext.implicits._
    import sqlContext._
    if(args.length < 1)
    {
      println("Missing Arguments")
    }
    val textfile = sc.textFile(args(0))
    val ebay = textfile.map(_.split("\\|")).map(p => Employee(p(0), p(1), p(2)))
    val readedfile = ebay.toDF
    readedfile.show()
    readedfile.collect().foreach(println)
  }
}