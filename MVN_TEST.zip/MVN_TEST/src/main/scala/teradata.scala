import com.teradata.jdbc.TeraDriver
import java.sql.Connection
import java.sql.DriverManager

object teradata {
  def main(args: Array[String]): Unit = {
    
    
    println("Teradata Connection")
    val driver = "com.teradata.jdbc.TeraDriver"
    val url = "jdbc:teradata://10.92.139.27/nrd_bip_sdb"
    val username = "unrd_etlcm_load"
    val password = "basel1234"
    var connection:Connection = null
        try {
      // make the connection
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)

      // create the statement, and run the select query
      val statement = connection.createStatement()
      val resultSet = statement.executeQuery("SELECT *  FROM nrd_bip_sdb.EMPLOYEE1 sample 100")
      //val data = Iterator.continually((rs.next(), rs)).takeWhile(_._1).map({case (_,rs) => rs.getString("col1") -> rs.getString("col2")}).toList
      //sc.parallelize(data).toDF().
      while ( resultSet.next() ) {
        val host = resultSet.getString("Employee_ID")
        val user = resultSet.getString("Employee_Name")
        println("host, user = " + host + ", " + user)
      }
    } catch {
      case e => e.printStackTrace
    }
    connection.close()

  }
}